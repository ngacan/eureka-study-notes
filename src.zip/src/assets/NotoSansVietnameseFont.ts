// This file is no longer in use.
// The app now relies on the default Roboto font bundled with pdfmake's vfs_fonts.js,
// which is more stable and provides full Vietnamese character support.
// This eliminates the need to embed a large Base64 font string here.
export const RobotoFont: string = '';